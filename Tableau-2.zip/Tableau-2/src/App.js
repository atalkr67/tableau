import Dashboard from "./components/Dashboard";
import DateFilter from "./components/DateFilter";
import TableauEmbed from "./components/TableauEmbed";
import TableauFilter from "./components/TableauFilter";
import TableauViz from "./components/TableauViz";
import Test from "./components/Test";
import Test2 from "./components/Test2";
import TestDashboard from "./components/TestDashboard";
import TableauDashboard from "./components/TestDate";
import DropdownFilter from "./components/DropdownFilter";

function App() {
  return (
    <div className="App">
      {/* <Dashboard/> */}
      {/* <DateFilter/> */}
      {/* <TableauEmbed/> */}
      {/* <Test/> */}
      {/* <Test2/> */}
      <TestDashboard/>
      {/* <TableauDashboard/> */}
      {/* <TableauViz/> */}
      {/* <TableauFilter/> */}
      {/* <DropdownFilter/> */}
    </div>
  );
}

export default App;
