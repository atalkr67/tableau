import React, { useEffect, useState } from 'react';

const TableauFilter = () => {
  const [startDate, setStartDate] = useState('2022-01-01');
  const [endDate, setEndDate] = useState('2022-12-31');
let viz;
  useEffect(() => {
    const initTableau = () => {
      const containerDiv = document.getElementById('tableauViz');
      const options = {
        hideTabs: true,
        hideToolbar: true,
        onFirstInteractive: (event) => {
          // Set initial date filter
          applyDateFilter(event, startDate, endDate);
        },
      };

       viz = new window.tableau.Viz(containerDiv, 'https://public.tableau.com/views/LearnEmbeddedAnalytics/SalesOverviewDashboard', options);
    };

    // Load Tableau API
    const script = document.createElement('script');
    script.src = 'https://public.tableau.com/javascripts/api/tableau-2.min.js';
    script.async = true;

    script.onload = initTableau;

    document.body.appendChild(script);

    return () => {
      // Cleanup
      document.body.removeChild(script);
      if(viz){
        viz.despose();
      }
    };
  }, [startDate, endDate]);

  const applyDateFilter = (event, start, end) => {
    const worksheet = event.getWorkbook().getActiveSheet().getWorksheets()[0];
    const dateFilter = {
      min: new Date(start),
      max: new Date(end),
    };

    const dateField = 'YourDateField'; // Replace with your actual date field
    const dateFilterAsync = worksheet.getRangeAsync({ fieldName: dateField, filterType: 'range' });

    dateFilterAsync.then((dateFilterOptions) => {
      dateFilterOptions.min = dateFilter.min;
      dateFilterOptions.max = dateFilter.max;
      worksheet.applyRangeFilterAsync(dateField, dateFilterOptions);
    });
  };

  const handleFilterApply = () => {
    // Trigger Tableau filter update when the user applies the manual date filter
    const containerDiv = document.getElementById('tableauViz');
    const viz = containerDiv && window.tableau.VizManager.getVizs()[0];

    if (viz) {
      applyDateFilter(viz.getWorkbook().getActiveSheet(), startDate, endDate);
    }
  };

  return (
    <div>
      <label htmlFor="startDate">Start Date:</label>
      <input
        type="date"
        id="startDate"
        value={startDate}
        onChange={(e) => setStartDate(e.target.value)}
      />

      <label htmlFor="endDate">End Date:</label>
      <input
        type="date"
        id="endDate"
        value={endDate}
        onChange={(e) => setEndDate(e.target.value)}
      />

      <button onClick={handleFilterApply}>Apply Filter</button>

      <div id="tableauViz"></div>
    </div>
  );
};

export default TableauFilter;
