import React, { useEffect, useState, useRef } from 'react';
import Dashboard from './Dashboard';


const DateFilter = () => {
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  var viz;
  const vizContainerRef = useRef(null);
  
  useEffect(() => {
    const initializeViz =  () => {
      const containerDiv = vizContainerRef.current;
      const vizUrl = "https://public.tableau.com/views/LearnEmbeddedAnalytics/SalesOverviewDashboard"; // Replace with your Tableau dashboard URL
      const options = {
        hideTabs: true,
        onFirstInteractive: () => {
          // Code to run when the viz is first interactive
        },
      };

       viz = new window.tableau.Viz(containerDiv, vizUrl, options);

      // Function to apply date filter
     


      // Clean up on component unmount
      return () => {
        viz.dispose();

      }
    }

    initializeViz();
  }, []);
//   const applyDateFilter = () => {
//     const sheet = viz.getWorkbook().getActiveSheet(); // Assuming the sheet is the active sheet
//     const dateFilter = {
//       fieldName: 'order', // Replace with your actual date field name
//       rangeType: 'range',
//       startDate,
//       endDate,
//     };
  
//     sheet[1].applyRangeFilterAsync(dateFilter.fieldName, dateFilter);
//   };
  
const applyDateFilter = () => {
    const sheet = viz.getWorkbook().getActiveSheet(); // Assuming the sheet is the active sheet
    const dateFilter = {
      fieldName: 'order', // Replace with your actual date field name
      rangeType: 'range',
      startDate,
      endDate,
    };
  
    sheet[1].applyRangeFilterAsync(dateFilter.fieldName, dateFilter);
  };
  const handleDropdownChange = (selectedValue) => {
    const sheet = viz.getWorkbook().getActiveSheet();
    const filter = sheet.getWorksheets()[0].getFilterAsync('fieldName');

    filter.then((filterAsync) => {
      filterAsync.setFilterAsync(selectedValue, window.tableau.FilterUpdateType.REPLACE);
    });
  };

  return (
    <div>
      <label>Start Date:</label>
      <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />

      <label>End Date:</label>
      <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} />

      <button onClick={applyDateFilter}>Apply Filter</button>
      <div ref={vizContainerRef} style={{ width: '100%', height: '500px' }}>
        {/* Container for Tableau Viz */}
      </div>
      <div>
        <label>Select Filter:</label>
        <select onChange={(e) => handleDropdownChange(e.target.value)}>
          <option value="Option1">Option 1</option>
          <option value="Option2">Option 2</option>
          {/* Add other options based on your data */}
        </select>
      </div>
    </div>
  );
};

export default DateFilter;
