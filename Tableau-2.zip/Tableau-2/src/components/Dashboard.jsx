import React, { useEffect, useRef } from 'react';
import tableau from 'tableau-api';

const Dashboard = () => {
  const vizContainerRef = useRef(null);
  var viz;

  useEffect(() => {
    const initializeViz = async () => {
      const containerDiv = vizContainerRef.current;
      const vizUrl = "https://public.tableau.com/views/LearnEmbeddedAnalytics/SalesOverviewDashboard"; // Replace with your Tableau dashboard URL
      const options = {
        hideTabs: true,
        onFirstInteractive: () => {
          // Code to run when the viz is first interactive
        },
      };

       viz = new window.tableau.Viz(containerDiv, vizUrl, options);

      // Function to apply date filter
      const applyDateFilter = (startDate, endDate) => {
        const worksheet = viz.getWorkbook().getActiveSheet().getWorksheets();
        const dateFilter = worksheet[0].getFilterAsync('OrderDate'); // Replace with the actual name of your date filter
        
        dateFilter.then((filter) => {
          filter.setRange({ start: startDate, end: endDate });
          filter.$applyAsync();
        });
      };

      // Event listener for date input change
      const onDateInputChange = () => {
        const startDate = document.getElementById('startDate').value;
        const endDate = document.getElementById('endDate').value;

        // Apply date filter when both start and end dates are selected
        if (startDate && endDate) {
          applyDateFilter(startDate, endDate);
        }
      };

      // Subscribe to date input change events
      document.getElementById('startDate').addEventListener('change', onDateInputChange);
      document.getElementById('endDate').addEventListener('change', onDateInputChange);

      // Clean up on component unmount
      return () => {
        viz.dispose();
        document.getElementById('startDate').removeEventListener('change', onDateInputChange);
        document.getElementById('endDate').removeEventListener('change', onDateInputChange);
      };
    };

    initializeViz();
  }, []);

  return (
    <div>
      <label htmlFor="startDate">Start Date:</label>
      <input type="date" id="startDate" />

      <label htmlFor="endDate">End Date:</label>
      <input type="date" id="endDate" />

      <div ref={vizContainerRef} style={{ width: '100%', height: '500px' }}>
        {/* Container for Tableau Viz */}
      </div>
    </div>
  );
};

export default Dashboard;
