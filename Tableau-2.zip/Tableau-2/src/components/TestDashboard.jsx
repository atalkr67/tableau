import React, { useEffect, useState, useRef } from "react";

function TestDashboard() {
  let viz;
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [filterValue, setFilterValue] = useState("All");
  const containerDiv = useRef(null);
  useEffect(() => {
    const url =
      "https://public.tableau.com/views/LearnEmbeddedAnalytics/SalesOverviewDashboard";

    const options = {
      hideTabs: false,
      height: 800,
      width: 1000,
      onFirstInteractive: function () {
        console.log("Hey, my dashboard is interactive!");
        console.log(viz);
      },
      onFirstVizSizeKnown: function () {
        console.log("Hey, my dashboard has a size!");
        console.log(viz);
      },
    };
    function initViz() {
      viz = new window.tableau.Viz(containerDiv.current, url, options);
      const dropdown = document.getElementById('filterDropdown');
      dropdown.addEventListener('change', (event) => {
        const filterValue = event.target.value;
        const sheet = viz.getWorkbook().getActiveSheet();

        // Assuming 'Category' is the field you want to filter
        sheet.applyFilterAsync('Region', filterValue, window.tableau.FilterUpdateType.REPLACE);
      });
    }
    //load Tableau api
    const script = document.createElement("script");
    script.src = "https://your-tableau-server/javascripts/api/tableau-2.min.js";
    script.addEventListener("load", initViz);
    document.body.appendChild(script);

    initViz();
    window.tableauViz = viz;

    return () => {
      viz.dispose();
      window.tableauViz = null;
        document.body.removeChild(script);
    };
  }, []);

  const getRangeValues = () => {
    const minValue = document.getElementById("minValue").value;
    const maxValue = document.getElementById("maxValue").value;

    const workbook = viz.getWorkbook();
    const activeSheet = workbook.getActiveSheet();
    const sheets = activeSheet.getWorksheets();
    console.log("sheets", sheets);
    const sheetToFilter = sheets[1];
    console.log("sheetToFilter", sheetToFilter);

    sheetToFilter
      .applyRangeFilterAsync("Sales", {
        min: minValue,
        max: maxValue,
      })
      .then(() => {
        console.log("Filter applied!");
      });
  };
  //   const filterFunction = () => {
  //     const sheet = window.tableau.Viz.getVizs()[0].getWorkbook().getActiveSheet();
  //     const dateFilter = {
  //       // Specify your date field name
  //       fieldName: 'Sales',
  //       rangeType: 'range',
  //       startDate,
  //       endDate,
  //     };

  //     sheet.applyRangeFilterAsync(dateFilter.fieldName, dateFilter);
  //   };

  //   const filterFunction = () => {
  //     const sheet = viz.getWorkbook().getActiveSheet(); // Assuming the sheet is the active sheet
  //     const dateFilter = {
  //       fieldName: "Sales", // Replace with your actual date field name
  //       rangeType: "range",
  //       startDate,
  //       endDate,
  //     };

  //     sheet.applyRangeFilterAsync(dateFilter.fieldName, dateFilter);
  //   };

  function dateFn1() {
    const sheet = viz.getWorkbook().getActiveSheet();
    const filter = sheet.getWorksheets()[0].getFilterAsync("YourFilterName");
    const dateFilter = {
      fieldName: "Order Date", // Replace with your actual date field name
      rangeType: "range",
      startDate,
      endDate,
    };
    filter.applyRangeFilterAsync(dateFilter.fieldName, dateFilter);
  }

  function dateFn2() {
    const worksheet = viz.getWorkbook().getActiveSheet().getWorksheets()[0];
    const filterDateRange = new window.tableau.Filter(
      "Order Date",
      window.tableau.FilterUpdateType.RANGE,
      {
        min: startDate,
        max: endDate,
      }
    );

    worksheet.applyFilterAsync(filterDateRange);
  }

  //   const handleDropdownChange = (selectedValue) => {
  //     const sheet = viz.getWorkbook().getActiveSheet();
  //     console.log("Region Sheet", sheet)
  //     // const filter = sheet.getWorksheets()[0].getFilterAsync("Region");
  //     sheet.setFilterAsync("Region").then((filterAsync) => {
  //         filterAsync.setFilterAsync(
  //           "Region",
  //           ["North"],
  //           window.tableau.FilterUpdateType.REPLACE
  //         );

  //     // filter.then((filterAsync) => {
  //     //   filterAsync.setFilterAsync(
  //     //     "Region",
  //     //     ["North"],
  //     //     window.tableau.FilterUpdateType.REPLACE
  //     //   );
  //     });
  //   };
  // function addValuesToSelection() {
  //     workbook.getActiveSheet().selectMarksAsync(
  //       "Region",
  //       ["Africa", "Oceania"],
  //       tableau.FilterUpdateType.ADD);
  //   }

  const handleDropdownChange = (filterValue) => {
    setFilterValue(filterValue)
    const workbook = viz.getWorkbook();
    const activeSheet = workbook.getActiveSheet();
    const sheets = activeSheet.getWorksheets();
    console.log("Region sheets", sheets);
    const sheetToFilter = sheets[1];
    console.log("Region sheetToFilter", sheetToFilter);
    sheetToFilter.clearFilterAsync("Sales").then(() => {
      console.log("Filter cleared");
    });
    // sheetToFilter
    //   .selectMarksAsync("Region", selectedValue,window.tableau.FilterUpdateType.REPLACE)
    //   .then(() => {
    //     console.log("Filter applied!");
    //   });
  };

  const handleDropdownChange1 = (e) => {
    // setFilterValue(value)
    // const sheet = viz.getWorkbook().getActiveSheet();
    // const filter = sheet.getWorksheets()[0].getFilterAsync("Sales");

    // filter.then((filterAsync) => {
    //   filterAsync.setFilterAsync(
    //     filterValue,
    //     window.tableau.FilterUpdateType.REPLACE
    //   );
    // });
    const selectedValue = e.target.value;
    setFilterValue(selectedValue);
    console.log(filterValue)
    const sheet = window.tableauViz.getWorkbook().getActiveSheet().getWorksheets()[0];
    const filterOptions = {
      fieldName: "Sales",
      values: [selectedValue],
    };

    // Remove existing filters
    sheet.getFiltersAsync().then((currentFilters) => {
      currentFilters.forEach((filter) => {
        filter.remove();
      });

      // Apply new filter
      sheet.applyFilterAsync(
        filterOptions.fieldName,
        filterOptions.values,
        window.tableau.FilterUpdateType.REPLACE
      );
    });
  };

  const applyDateFilter1 = () => {
    if (viz) {
      const sheet = viz.getWorkbook().getActiveSheet();
      const dateFilter = {
        fieldName: "Order Date",
        rangeType: "range",
        startDate,
        endDate,
      };

      if (sheet.getSheetType() === "worksheet") {
        sheet.applyRangeFilterAsync("Region", ["North"]);
      } else {
        const worksheetArray = sheet.getWorksheets();

        for (var i = 0; i < worksheetArray.length; i++) {
          worksheetArray[i].applyRangeFilterAsync(
            dateFilter.fieldName,
            dateFilter
          );
        }
      }
    }
  };

  return (
    <>
      <div>
        <input type="text" id="minValue" placeholder="Min Value" />
        <input type="text" id="maxValue" placeholder="Max Value" />
        <button id="applyFilter" onClick={getRangeValues}>
          Apply Filter
        </button>
      </div>
      <div>
        <div>
          <label>Select Filter:</label>
          <select value={filterValue} onChange={handleDropdownChange1}>
            <option value="All"> All</option>
            <option value="Central">Central</option>
            <option value="North">North</option>
            <option value="South">South</option>
          </select>
        </div>
      </div>
      <div>
        <label>Start Date:</label>
        <input
          type="date"
          value={startDate}
          onChange={(e) => setStartDate(e.target.value)}
        />

        <label>End Date:</label>
        <input
          type="date"
          value={endDate}
          onChange={(e) => setEndDate(e.target.value)}
        />

        <button onClick={dateFn1}>Apply Filter</button>
      </div>
      <label htmlFor="filterDropdown">Select a category:</label>
      <select id="filterDropdown">
        <option value="All">All</option>
        <option value="North">North</option>
        <option value="South">South</option>
        <option value="Central">Central</option>
        {/* Add more options based on your data */}
      </select>
      <div ref={containerDiv}></div>
    </>
  );
}

export default TestDashboard;
