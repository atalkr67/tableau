import React, { useEffect, useState, useRef } from "react";

function Test2() {
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const vizContainerDiv = useRef(null);
  let viz;

  useEffect(() => {
    const url =
      "https://public.tableau.com/views/LearnEmbeddedAnalytics/SalesOverviewDashboard";
    const options = {
      hideTabs: true,
      height: 800,
      width: 1000,
      onFirstInteractive: function () {
        console.log("Hey, my dashboard is interactive!");
        // Now that the viz is interactive, set the event listener
        viz.addEventListener(
          window.tableau.TableauEventName.FILTER_CHANGE,
          applyDateFilter1
        );
      },
    };

    if (window.tableau) {
      viz = new window.tableau.Viz(vizContainerDiv.current, url, options);
    }

    // Cleanup on component unmount
    return () => {
      if (viz) {
        viz.dispose();
      }
    };
  }, []);


  const applyDateFilter1 = () => {
    if (viz) {
      const sheet = viz.getWorkbook().getActiveSheet();
      const dateFilter = {
        fieldName: "Order Date",
        rangeType: "range",
        startDate,
        endDate,
      };

      if (sheet.getSheetType() === "worksheet") {
        sheet.applyRangeFilterAsync(dateFilter.fieldName, dateFilter);
      } else {
        const worksheetArray = sheet.getWorksheets();

        for (var i = 0; i < worksheetArray.length; i++) {
          worksheetArray[i].applyRangeFilterAsync(
            dateFilter.fieldName,
            dateFilter
          );
        }
      }
    }
  };
  function applyDateFilter2(startDate, endDate) {
    const sheet = viz.getWorkbook().getActiveSheet();

    const filterOptions = {
      min: startDate,
      max: endDate,
    };

    if (sheet.getSheetType() === "worksheet") {
      sheet.applyRangeFilterAsync("Order Date", filterOptions).then(function(filter){
        let values = filter.getAppliedValues();
        // let values = filter.$9
        console.log(values)
    });
    } else {
      const worksheetArray = sheet.getWorksheets();

      for (var i = 0; i < worksheetArray.length; i++) {
        worksheetArray[i].applyRangeFilterAsync("Order Date", filterOptions);
      }
    }
  }
  const handleDropdownChange = (selectedValue) => {
    const sheet = viz.getWorkbook().getActiveSheet();
    const filter = sheet.getWorksheets()[0].getFilterAsync('Sales');

    filter.then((filterAsync) => {
      filterAsync.setFilterAsync(selectedValue, window.tableau.FilterUpdateType.REPLACE);
    });
  };
  const getRangeValues = () => {
    const minValue = document.getElementById("minValue").value;
    const maxValue = document.getElementById("maxValue").value;

    const workbook = viz.getWorkbook();
    const activeSheet = workbook.getActiveSheet();
    const sheets = activeSheet.getWorksheets();
    const sheetToFilter = sheets[1];

    sheetToFilter
      .applyRangeFilterAsync("Sales", {
        min: minValue,
        max: maxValue
      })
      .then(() => {
        console.log("Filter applied!");
      });

     

      
  };

  return (
    <div>
      <input type="text" id="minValue" placeholder="Min Value"  />
      <input type="text" id="maxValue" placeholder="Max Value" />
      <button id="applyFilter" onClick={getRangeValues}>Apply Filter</button>
       <div>
        <label>Select Filter:</label>
        <select onChange={(e) => handleDropdownChange(e.target.value)}>
          <option value="Option1"> All</option>
          <option value="Option2">Central</option>
          <option value="Option2">North</option>
          <option value="Option2">South</option>
        </select>
      </div>
      <label>Start Date:</label>
      <input
        type="date"
        value={startDate}
        onChange={(e) => setStartDate(e.target.value)}
      />

      <label>End Date:</label>
      <input
        type="date"
        value={endDate}
        onChange={(e) => setEndDate(e.target.value)}
      />

      <button onClick={applyDateFilter1}>Apply Filter 1</button>
      {/* "Apply Filter 2" button doesn't need an onClick handler */}
      <button onClick={() => applyDateFilter2(startDate, endDate)}>
        Apply Filter 2
      </button>
     
      <div ref={vizContainerDiv}></div>

    </div>
  );
}

export default Test2;
