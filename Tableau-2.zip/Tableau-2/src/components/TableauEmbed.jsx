import React, { useState, useEffect } from 'react';
import {
  TableauViz,
  TableauEventType
} from "https://public.tableau.com/javascripts/api/tableau.embedding.3.latest.js";

const TableauEmbed = () => {
  const [newBase, setNewBase] = useState('');

  const setVizParam = async () => {
    try {
      const viz = new window.tableau.VizManager.getVizs()[0]; // Assuming there's only one viz on the page
      await viz.workbook.changeParameterValueAsync('Base Salary', newBase);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    const script = document.createElement('script');
    script.type = 'module';
    script.src = 'https://public.tableau.com/javascripts/api/tableau.embedding.3.latest.js';
    script.async = true;

    script.onload = () => {
      // Tableau JS API is loaded
      // You can now access window.tableau object
    };

    document.head.appendChild(script);

    return () => {
      // Cleanup function
      document.head.removeChild(script);
    };
  }, []); // Run only once when the component mounts

  return (
    <div>
      <h1>Embedding API v3 Demo - Change Parameters</h1>
      <form>
        <input
          type="number"
          min="0"
          step="1000"
          value={newBase}
          onChange={(e) => setNewBase(e.target.value)}
          placeholder="Base Salary"
        />
        <button type="button" onClick={setVizParam}>
          Change Parameter
        </button>
      </form>
      <div id="main">
        <tableau-viz
          id="tableauViz"
          src="https://public.tableau.com/views/Superstore_800_600/CommissionModel"
          toolbar="hidden"
          hide-tabs
        />
      </div>
    </div>
  );
};

export default TableauEmbed;