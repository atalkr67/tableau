import React, { useEffect, useState, useRef } from "react";

function Test() {

  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const vizContainerDiv = useRef(null);

  var viz;

  useEffect(() => {
    const url =
      "https://public.tableau.com/views/LearnEmbeddedAnalytics/SalesOverviewDashboard";
    const options = {
      hideTabs: true,
      height: 800,
      width: 1000,
      onFirstInteractive: function () {
        console.log("Hey, my dashboard is interactive!");
        console.log(viz);
      },
      onFirstVizSizeKnown: function () {
        console.log("Hey, my dashboard has a size!");
        console.log(viz);
      },
    };
     function initViz() {
      viz =  new window.tableau.Viz(vizContainerDiv, url, options);
      viz.addEventListener(window.tableau.TableauEventName.FILTER_CHANGE, applyDateFilter1)
      console.log(viz)
      console.log(viz.current)
    }

    initViz();

    // Cleanup on component unmount
    return () => {
       viz.dispose();
    };
  }, []);

  function applyDateFilter2(startDate, endDate) {
    const sheet = viz.getWorkbook().getActiveSheet();

    const filterOptions = {
      min: startDate,
      max: endDate,
    };

    if (sheet.getSheetType() === "worksheet") {
      sheet.applyRangeFilterAsync("Order Date", filterOptions).then(function(filter){
        let values = filter.getAppliedValues();
        // let values = filter.$9
        console.log(values)
    });
    } else {
      const worksheetArray = sheet.getWorksheets();

      for (var i = 0; i < worksheetArray.length; i++) {
        worksheetArray[i].applyRangeFilterAsync("Order Date", filterOptions);
      }
    }
  }

  const applyDateFilter1 = () => {
    const sheet = viz.getWorkbook().getActiveSheet(); // Assuming the sheet is the active sheet
    const dateFilter = {
      fieldName: "Order Date", // Replace with your actual date field name
      rangeType: "range",
      startDate,
      endDate,
    };

    // sheet[1].applyRangeFilterAsync(dateFilter.fieldName, dateFilter);
    if (sheet.getSheetType() === "worksheet") {
      sheet.applyRangeFilterAsync(dateFilter.fieldName, dateFilter);
    } else {
      const worksheetArray = sheet.getWorksheets();

      for (var i = 0; i < worksheetArray.length; i++) {
        worksheetArray[i].applyRangeFilterAsync("Order Date",JSON.stringify(dateFilter));
      }
    }
  };

  return (
    <div>
      <label>Start Date:</label>
      <input
        type="date"
        value={startDate}
        onChange={(e) => setStartDate(e.target.value)}
      />

      <label>End Date:</label>
      <input
        type="date"
        value={endDate}
        onChange={(e) => setEndDate(e.target.value)}
      />

      <button onClick={applyDateFilter1}>Apply Filter 1</button>
      <button onClick={applyDateFilter2}>Apply Filter 2</button>
      <div ref={vizContainerDiv}></div>
    </div>
  );
}

export default Test;
