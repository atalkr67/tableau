import React, { useEffect,useState } from "react";

const TableauViz = () => {
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  useEffect(() => {
    // Load Tableau Embedding Library
    const script = document.createElement("script");
    script.type = "module";
    script.src =
      "https://public.tableau.com/javascripts/api/tableau.embedding.3.latest.min.js";
    script.async = true;

    document.body.appendChild(script);

    script.onload = () => {
      // Initialize Tableau Viz
      const containerDiv = document.getElementById("tableauViz");
      const options = {
        hideTabs: true,
        hideToolbar: true,
        onFirstInteractive: (event) => {
          // Set initial parameter values
          event
            .getWorkbook()
            .changeParameterValueAsync("Start Date", "2022-01-01");
          event
            .getWorkbook()
            .changeParameterValueAsync("End Date", "2022-12-31");
        },
      };

      const viz = new window.tableau.Viz(
        containerDiv,
        "https://public.tableau.com/views/EmbedAPIv3changingparametersExample/Dashboard1",
        options
      );
    };
    // https://public.tableau.com/views/EmbedAPIv3changingparametersExample/Dashboard1
    return () => {
      // Cleanup
      document.body.removeChild(script);
    };
  }, []);

  return (
    <>
    
      <div id="tableauViz">
      <input
          type="date"
          value={startDate}
          onChange={(e) => setStartDate(e.target.value)}
        />

        <label>End Date:</label>
        <input
          type="date"
          value={endDate}
          onChange={(e) => setEndDate(e.target.value)}
        />
        <viz-parameter name="Start Date" value={startDate}></viz-parameter>
        <viz-parameter name="End Date" value={endDate}></viz-parameter>
      </div>
    </>
  );
};

export default TableauViz;
