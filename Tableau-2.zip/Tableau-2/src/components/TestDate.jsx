import React, { useEffect,useState } from 'react';

const TableauDashboard = () => {
    
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  useEffect(() => {
    const containerDiv = document.getElementById('tableauContainer');

    const options = {
      hideTabs: true,
      hideToolbar: true,
      onFirstInteractive: (event) => {
        // Add any additional setup after the dashboard has loaded
        const workbook = event.getWorkbook();
        const activeSheet = workbook.getActiveSheet();
        
        // Apply date range filter
        const dateFilter = {
          min: new Date(startDate),
          max: new Date(endDate),
        };

        const dateField = 'YourDateField'; // Replace with your actual date field
        const dateFilterAsync = activeSheet.getRangeAsync({ fieldName: dateField, filterType: 'range' });
        
        dateFilterAsync.then((dateFilterOptions) => {
          dateFilterOptions.min = dateFilter.min;
          dateFilterOptions.max = dateFilter.max;
          activeSheet.applyRangeFilterAsync(dateField, dateFilterOptions);
        });
      },
    };

    const url = 'https://your-tableau-server/views/YourDashboard';

    const viz = new window.tableau.Viz(containerDiv, url, options);

    return () => {
      // Clean up if needed
      viz.dispose();
    };
  }, [startDate, endDate]);

  return (
    <>
    <label>Start Date:</label>
      <input
        type="date"
        value={startDate}
        onChange={(e) => setStartDate(e.target.value)}
      />

      <label>End Date:</label>
      <input
        type="date"
        value={endDate}
        onChange={(e) => setEndDate(e.target.value)}
      />
    <div id="tableauContainer" />
    </>
  );
};

export default TableauDashboard;
