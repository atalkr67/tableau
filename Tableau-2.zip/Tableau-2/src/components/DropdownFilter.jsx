import React, { useEffect } from "react";
import tableau from "tableau-api";

let viz;
const TableauDashboard = () => {
  useEffect(() => {
    const initTableau = () => {
      const containerDiv = document.getElementById("tableauContainer");
      const url =
        "https://public.tableau.com/views/LearnEmbeddedAnalytics/SalesOverviewDashboard";

      const options = {
        hideTabs: true,
        onFirstInteractive: () => {
          // Place any initialization logic here
        },
      };
      if (viz) {
        viz.dispose();
      } else {
        viz = new window.tableau.Viz(containerDiv, url, options);
      }

      // Add event listener for dropdown change
      const dropdown = document.getElementById("filterDropdown");
      dropdown.addEventListener("change", (event) => {
        const filterValue = event.target.value;
        const sheet = viz.getWorkbook().getActiveSheet();

        // Assuming 'Category' is the field you want to filter
        sheet.applyFilterAsync(
          "Region",
          filterValue,
          tableau.FilterUpdateType.REPLACE
        );
      });
    };

    initTableau();
  }, []);

  return (
    <div>
      <label htmlFor="filterDropdown">Select a category:</label>
      <select id="filterDropdown">
        <option value="Category1">Category 1</option>
        <option value="Category2">Category 2</option>
        <option value="Category3">Category 3</option>
        {/* Add more options based on your data */}
      </select>

      <div id="tableauContainer"></div>
    </div>
  );
};

export default TableauDashboard;
